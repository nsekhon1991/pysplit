RAMS6 TO ARL FORMAT DATA CONVERTER (requires some code from the rams5 directory)
---------------------------------------------------------------------------------

All the source (save for the HDF5 libs) is in the attached gzip tar file.  
Instructions are as follows:

Download HDF5 libs from http://hdf.ncsa.uiuc.edu/HDF5/  I'm expecting the archive libs 
to be present (not the shared objects), though the build structure can obviously be 
modified to accommodate shared objects

Explode the attached tarball to yield the RAMS6_ARL/bin and RAMS6_ARL/src directories.

cd RAMS6_ARL/bin/utils

Edit paths.mk and modify RAMS_ROOT

Edit include.mk.opt to set compiler options for your platform.  This has only been tested 
on the SGI; since this includes loads of Craig Tremback's code, it'll *probably* work under 
Linux/pgf90.  No other platforms have been tested.

Make the utils archive: "make -f make.utils.opt"

cd ..  (PWD=RAMS6_ARL/bin)
Edit paths.mk and modify RAMS_ROOT
Edit include.mk.opt to set compiler options for your platform.
Make the executable: "make OPT=opt"

Execution:  There is a sample job script in RAMS6_ARL/bin.  This is similar to previous 
versions of this script, except the time interval has been removed, and the suffix of the 
RAMS files is truncated (the code adds the suffix automatically).  I removed the time 
interval specification since the converter now parses the date/time of the forecast from 
the list of files in the job script.  RAMS6 allows different grids to be written at
different intervals. The majority of these mods are in RAMS6_ARL/src/arl/rams_arl.f90.

RAMS6 is now distributed under Gnu PL...distro of parts of this code are governed by that.
Most of the rest is the old UofH converter.
