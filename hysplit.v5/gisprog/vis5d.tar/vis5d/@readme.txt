VIS5D - Convert Hysplit Binary Concentration File
Last Revised: 6 October 2003
___________________________________________________________________

The executable for con2vis is not provided as the program needs to be
compiled with appropriate Vis5d libaries on the platform the software 
will be running.  Typically applications are run under UNIX or LINUX.
See http://www.ssec.wisc.edu/~billh/vis5d.html. Comparable other 
applications the Hysplit output is first converted to VIS5D format:

	con2vis [hysplit input file]  [vis5d output file]

Then VIS5D is started with the converted file:

	vis5d [vis5d outfile file]
